(function(){
"use strict";
var C=window.CLOUD_CFG||{};if(!C.url||!C.key)return;
var SK="cl_sess",BK="cl_base",DK="cl_dirty",PK="cl_prof",TK="cl_time";
function rd(k){try{return JSON.parse(localStorage.getItem(k))}catch(e){return null}}
function wr(k,v){try{if(v==null)localStorage.removeItem(k);else localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
var sess=rd(SK),prof=rd(PK),busy=false,tm=null,state="idle",RO=false,errMsg="";
var orig=window.save;
var qs=new URLSearchParams(location.search),VIEW=qs.get("view"),VNAME=qs.get("n")||"";

/* ---------- HTTP ---------- */
function jf(url,o){return fetch(url,o).then(function(r){return r.text().then(function(t){var j=null;try{j=JSON.parse(t)}catch(e){}return{ok:r.ok,status:r.status,json:j}})})}
function ah(t){var h={apikey:C.key,"Content-Type":"application/json"};if(t)h.Authorization="Bearer "+t;return h}
function setSess(j){sess={at:j.access_token,rt:j.refresh_token,exp:Date.now()+(j.expires_in||3600)*1000-60000,uid:j.user.id,email:j.user.email};wr(SK,sess)}
async function login(email,pw){var r;try{r=await jf(C.url+"/auth/v1/token?grant_type=password",{method:"POST",headers:ah(),body:JSON.stringify({email:email,password:pw})})}catch(e){throw new Error("تعذر الاتصال بالإنترنت")}
if(!r.ok)throw new Error("البريد أو كلمة المرور غير صحيحة");setSess(r.json)}
async function token(){if(!sess)throw new Error("noauth");if(Date.now()<sess.exp)return sess.at;var r;
try{r=await jf(C.url+"/auth/v1/token?grant_type=refresh_token",{method:"POST",headers:ah(),body:JSON.stringify({refresh_token:sess.rt})})}catch(e){throw new Error("offline")}
if(!r.ok){if(r.status>=400&&r.status<500){logout(true);throw new Error("noauth")}throw new Error("offline")}
setSess(r.json);return sess.at}
async function rest(path,method,body,prefer){var t=await token(),h=ah(t);if(prefer)h.Prefer=prefer;
try{return await jf(C.url+"/rest/v1/"+path,{method:method||"GET",headers:h,body:body?JSON.stringify(body):undefined})}catch(e){throw new Error("offline")}}
function logout(silent){sess=null;prof=null;wr(SK,null);wr(PK,null);wr(BK,null);wr(DK,null);setState("login");if(!silent)panel()}

/* ---------- UI ---------- */
var st=document.createElement("style");st.textContent="#clchip{position:fixed;top:calc(6px + env(safe-area-inset-top,0px));left:6px;z-index:95;font:700 12px/1 inherit;padding:6px 9px;border-radius:999px;border:1px solid rgba(0,0,0,.15);background:rgba(255,255,255,.88);color:#1d2a26;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.15)}#clchip.ok{color:#0b7a3b}#clchip.err,#clchip.off{color:#b45309}#clchip.login{color:#b91c1c}.clc{background:var(--sf,#fff);color:var(--tx,#1d2a26);border-radius:22px;padding:20px;width:100%;max-width:360px;max-height:90vh;overflow:auto;box-shadow:0 20px 50px rgba(0,0,0,.5);text-align:center}.clc h3{margin:0 0 6px;font-size:18px}.clc p{margin:4px 0 8px;font-size:14px;opacity:.85;line-height:1.6}.clc input{width:100%;box-sizing:border-box;margin-top:8px;padding:12px;border-radius:12px;border:1px solid #cbd5e1;font-size:16px;font-family:inherit;direction:ltr;text-align:left;background:#fff;color:#111}.clb{display:block;width:100%;margin-top:10px;padding:13px;border:0;border-radius:14px;font-size:16px;font-weight:700;font-family:inherit;cursor:pointer;background:#e2e8f0;color:#1e293b}.clb.g{background:linear-gradient(180deg,#34d97b,#128c4a);color:#fff}.clb.r{background:#fee2e2;color:#991b1b}.clb.t{background:transparent;color:inherit;opacity:.7}.clr{font-size:13px;margin-top:6px;text-align:right;background:rgba(0,0,0,.05);border-radius:10px;padding:8px 10px}#clro{position:fixed;top:0;left:0;right:0;z-index:300;background:#b45309;color:#fff;text-align:center;padding:calc(6px + env(safe-area-inset-top,0px)) 10px 6px;font-size:14px;font-weight:700}#clro a{color:#fff;text-decoration:underline;margin-inline-start:10px}";
document.head.appendChild(st);
var chip=document.createElement("button");chip.id="clchip";chip.type="button";chip.onclick=function(){panel()};document.body.appendChild(chip);
function setState(s,m){state=s;errMsg=m||"";var t={idle:"☁",ok:"☁ ✓",sync:"☁ ⟳",dirty:"☁ ●",off:"☁ بلا اتصال",err:"☁ ⚠",login:"☁ تسجيل الدخول"}[s]||"☁";chip.textContent=t;chip.className=s;chip.title=m||""}
function box(html,locked){var e=document.getElementById("cld");if(!e){e=document.createElement("div");e.id="cld";e.style.cssText="position:fixed;inset:0;z-index:600;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;padding:16px;direction:rtl";document.body.appendChild(e)}
e.style.display="flex";e.innerHTML='<div class="clc">'+html+"</div>";e.onclick=locked?null:function(ev){if(ev.target===e)closeBox()};return e}
function closeBox(){var e=document.getElementById("cld");if(e)e.style.display="none"}
function $(i){return document.getElementById(i)}
function esc(t){return String(t==null?"":t).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function choice(title,body,opts){return new Promise(function(res){var h="<h3>"+title+"</h3>"+body;opts.forEach(function(o,i){h+='<button type="button" class="clb '+(o.c||"")+'" data-i="'+i+'">'+o.t+"</button>"});
var e=box(h,true);e.querySelectorAll("button[data-i]").forEach(function(b){b.onclick=function(){closeBox();res(+b.getAttribute("data-i"))}})})}
function cnt(d){d=d||{};return(d.mem||[]).length+" عضو، "+(d.v||[]).length+" سند، سنة "+(d.year||"")}
function when(t){try{return new Date(t).toLocaleString("ar-SY")}catch(e){return""}}
function panel(){
if(!sess){var locked=!!C.requireLogin;
box('<h3>المزامنة السحابية</h3><p>سجّل الدخول بحساب جمعيتك لحفظ بياناتك على السحابة ومزامنتها.</p><input id="clem" type="email" placeholder="البريد الإلكتروني" autocomplete="username"><input id="clpw" type="password" placeholder="كلمة المرور" autocomplete="current-password"><div id="clerr" class="clr" style="display:none;color:#b91c1c"></div><button id="cllg" class="clb g" type="button">دخول</button>'+(locked?"":'<button id="clcl" class="clb t" type="button">لاحقًا</button>'),locked);
if($("clcl"))$("clcl").onclick=closeBox;
$("cllg").onclick=async function(){var b=$("cllg"),er=$("clerr");er.style.display="none";b.disabled=true;b.textContent="جاري الدخول…";
try{await login($("clem").value.trim(),$("clpw").value);await loadProf();closeBox();afterLogin()}catch(e){er.textContent=e.message==="profile"?"تعذر قراءة بيانات الحساب":e.message;er.style.display="block";b.disabled=false;b.textContent="دخول"}};return}
var isA=prof&&prof.role==="admin",h="<h3>المزامنة السحابية</h3>";
h+='<div class="clr">الحساب: <b style="direction:ltr;display:inline-block">'+esc(sess.email)+"</b></div>";
if(prof&&prof.org_id)h+='<div class="clr">الجمعية: <b>'+esc(prof.name||"")+"</b>"+(prof.active===false?' <span style="color:#b91c1c">(معطّلة)</span>':"")+"</div>";
else h+='<div class="clr">'+(isA?"حساب أدمن غير مربوط بجمعية. استخدم لوحة الأدمن.":"هذا الحساب غير مربوط بأي جمعية. تواصل مع الأدمن.")+"</div>";
var labels={idle:"جاهز",ok:"متزامن",sync:"جاري المزامنة…",dirty:"تغييرات بانتظار الرفع",off:"بلا اتصال — ستُرفع التغييرات لاحقًا",err:"خطأ: "+errMsg,login:"يلزم تسجيل الدخول"};
h+='<div class="clr">الحالة: <b>'+(labels[state]||state)+"</b>"+(rd(TK)?"<br>آخر مزامنة: "+when(rd(TK)):"")+"</div>";
if(prof&&prof.org_id)h+='<button id="clsy" class="clb g" type="button">مزامنة الآن</button><button id="clup" class="clb" type="button">رفع نسختي إلى السحابة</button><button id="cldn" class="clb" type="button">تنزيل نسخة السحابة إلى هذا الجهاز</button>';
if(isA)h+='<button id="clad" class="clb" type="button">لوحة الأدمن</button>';
h+='<button id="clou" class="clb r" type="button">تسجيل الخروج</button><button id="clcl" class="clb t" type="button">إغلاق</button>';
box(h);$("clcl").onclick=closeBox;
if($("clsy"))$("clsy").onclick=function(){closeBox();sync(true)};
if($("clup"))$("clup").onclick=async function(){closeBox();if(await choice("رفع نسختي","<p>ستحلّ بيانات هذا الجهاز ("+cnt(S)+") محل نسخة السحابة. تُحفظ النسخة السابقة في سجل النسخ.</p>",[{t:"رفع",c:"g"},{t:"إلغاء",c:"t"}])===0)forceUp()};
if($("cldn"))$("cldn").onclick=async function(){closeBox();if(await choice("تنزيل من السحابة","<p>ستحلّ نسخة السحابة محل بيانات هذا الجهاز. تُحفظ نسخة احتياطية محلية قبل ذلك.</p>",[{t:"تنزيل",c:"g"},{t:"إلغاء",c:"t"}])===0)forceDown()};
if($("clad"))$("clad").onclick=function(){location.href=C.adminUrl||"admin.html"};
$("clou").onclick=async function(){closeBox();if(rd(DK)&&await choice("تنبيه","<p>لديك تغييرات لم تُرفع بعد وستبقى في هذا الجهاز فقط. هل تريد الخروج؟</p>",[{t:"خروج",c:"r"},{t:"إلغاء",c:"t"}])!==0)return;logout(false)}}

/* ---------- Data ---------- */
async function loadProf(){var r=await rest("profiles?select=org_id,role&user_id=eq."+sess.uid);if(!r.ok)throw new Error("profile");
var p=r.json&&r.json[0]||{org_id:null,role:"none"};
if(p.org_id){var o=await rest("orgs?select=name,active&id=eq."+p.org_id);var oo=o.json&&o.json[0];p.name=oo?oo.name:"";p.active=oo?oo.active:true}
prof=p;wr(PK,p)}
async function meta(full){var r=await rest("app_state?select="+(full?"version,updated_at,data":"version,updated_at")+"&org_id=eq."+prof.org_id);if(!r.ok)throw new Error("rest "+r.status);return r.json&&r.json[0]||null}
function apply(d,ver){var bak=null;try{bak=localStorage.getItem(K)}catch(e){}try{if(bak)localStorage.setItem(K+"_before_cloud",bak)}catch(e){}
S=d;try{fix10();mig();mig2()}catch(e){}orig();wr(BK,ver);wr(DK,null);wr(TK,Date.now());try{go()}catch(e){}}
async function insert(){var r=await rest("app_state","POST",{org_id:prof.org_id,data:S,version:1,updated_by:sess.uid},"return=representation");
if(r.status===409)return"conflict";if(!r.ok)throw new Error("رفض الخادم الحفظ ("+r.status+")");wr(BK,1);wr(DK,null);wr(TK,Date.now());return"ok"}
async function push(base){var r=await rest("app_state?org_id=eq."+prof.org_id+"&version=eq."+base,"PATCH",{data:S,version:base+1,updated_at:new Date().toISOString(),updated_by:sess.uid},"return=representation");
if(!r.ok)throw new Error("رفض الخادم الحفظ ("+r.status+")");if(r.json&&r.json.length){wr(BK,base+1);wr(DK,null);wr(TK,Date.now());return"ok"}return"conflict"}
async function resolve(m0){var m=await meta(true);if(!m){return await insert()}
var dirty=!!rd(DK),first=rd(BK)==null;
var i=await choice(first?"بيانات على السحابة":"تعارض في البيانات",
"<p>"+(first?"هذا الجهاز لم يُربط بالسحابة من قبل.":"تغيّرت بيانات الجمعية على السحابة من جهاز آخر وعندك تغييرات محلية.")+"</p><div class='clr'>على السحابة: <b>"+cnt(m.data)+"</b><br>آخر تحديث: "+when(m.updated_at)+"</div><div class='clr'>على هذا الجهاز: <b>"+cnt(S)+"</b></div><p>أي النسختين تعتمد؟ النسخة التي لا تختارها لا تضيع: نسخة السحابة السابقة تبقى في السجل، وبيانات الجهاز تُحفظ محليًا قبل الاستبدال.</p>",
[{t:"اعتماد نسخة السحابة",c:"g"},{t:"اعتماد نسخة هذا الجهاز ورفعها",c:""},{t:"قرّر لاحقًا",c:"t"}]);
if(i===0){apply(m.data,m.version);return"ok"}
if(i===1){var r=await push(m.version);return r}
return"later"}
async function sync(manual){if(RO||busy||!sess||!prof||!prof.org_id)return;
if(!navigator.onLine){setState("off");return}
if(prof.active===false){setState("err","الجمعية معطّلة");return}
busy=true;setState("sync");
try{var base=rd(BK),dirty=!!rd(DK),m=await meta(false),res="ok";
if(!m){var c=await choice("رفع بيانات الجمعية","<p>لا توجد بيانات لهذه الجمعية على السحابة بعد. ستُرفع بيانات هذا الجهاز: <b>"+cnt(S)+"</b></p><p>تأكد أن هذه بيانات الجمعية الصحيحة ("+esc(prof.name||"")+").</p>",[{t:"رفع الآن",c:"g"},{t:"ليس الآن",c:"t"}]);
if(c!==0){setState("idle");busy=false;return}res=await insert()}
else if(base==null){res=await resolve()}
else if(m.version>base){if(dirty)res=await resolve();else{var f=await meta(true);apply(f.data,f.version)}}
else if(dirty){res=await push(base);if(res==="conflict")res=await resolve()}
else{wr(TK,Date.now())}
if(res==="conflict")res=await resolve();
setState(res==="later"?"dirty":"ok")}
catch(e){if(e.message==="noauth"){setState("login");}else if(e.message==="offline"){setState("off")}else{setState("err",e.message)}}
finally{busy=false}}
async function forceUp(){busy=true;setState("sync");try{var m=await meta(false);var r=m?await push(m.version):await insert();if(r==="conflict")throw new Error("تغيّرت البيانات أثناء الرفع، أعد المحاولة");setState("ok")}catch(e){setState(e.message==="offline"?"off":"err",e.message)}finally{busy=false}}
async function forceDown(){busy=true;setState("sync");try{var m=await meta(true);if(!m)throw new Error("لا توجد بيانات على السحابة");apply(m.data,m.version);setState("ok")}catch(e){setState(e.message==="offline"?"off":"err",e.message)}finally{busy=false}}

/* ---------- save hook ---------- */
window.save=function(){var r=orig.apply(this,arguments);
if(!RO&&sess&&prof&&prof.org_id){wr(DK,1);setState(navigator.onLine?"dirty":"off");clearTimeout(tm);tm=setTimeout(function(){sync()},2500)}return r};

/* ---------- read-only view for admin ---------- */
async function viewMode(){try{var r=await rest("app_state?select=data,version,updated_at&org_id=eq."+encodeURIComponent(VIEW));var row=r.json&&r.json[0];if(!r.ok||!row){choice("تعذر العرض","<p>لا توجد بيانات لهذه الجمعية أو لا تملك صلاحية.</p>",[{t:"رجوع",c:"g"}]).then(function(){location.href=C.adminUrl||"admin.html"});return}
RO=true;window.save=function(){};S=row.data;try{fix10();mig();mig2()}catch(e){}
var b=document.createElement("div");b.id="clro";b.innerHTML="وضع العرض فقط — "+esc(VNAME)+" (نسخة "+row.version+") <a href='"+(C.adminUrl||"admin.html")+"'>رجوع للوحة الأدمن</a>";document.body.appendChild(b);document.body.style.paddingTop="44px";chip.style.top="48px";
try{go()}catch(e){}}catch(e){setState("err",e.message)}}

/* ---------- start ---------- */
function afterLogin(){if(prof&&prof.org_id)sync(true);else setState("ok")}
async function start(){
if(!sess){setState("login");if(C.requireLogin)panel();return}
setState("idle");
try{if(!prof)await loadProf()}catch(e){if(e.message==="noauth"){setState("login");if(C.requireLogin)panel();return}}
if(VIEW&&prof&&prof.role==="admin"){viewMode();return}
if(prof&&prof.org_id){if(rd(DK))setState("dirty");sync()}else setState("ok")}
window.addEventListener("online",function(){sync()});
document.addEventListener("visibilitychange",function(){if(!document.hidden)sync()});
setInterval(function(){sync()},90000);
setTimeout(start,600);
window.CLOUD={sync:sync,panel:panel};
})();
