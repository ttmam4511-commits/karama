window.CLOUD_CFG={
  url:"https://rdjglmeguffuheyuiutn.supabase.co",
  key:"sb_publishable_7VvowkG73FcayehjK3Ffrg_wiDGqMcS",
  requireLogin:false,
  adminUrl:"admin.html"
};
