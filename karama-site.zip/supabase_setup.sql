-- نفّذ هذا الملف مرة واحدة في Supabase: SQL Editor ثم New query ثم Run
create table if not exists orgs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  active boolean not null default true,
  created_at timestamptz not null default now());
create table if not exists profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  org_id uuid references orgs(id) on delete set null,
  role text not null default 'member' check (role in ('member','admin')));
create table if not exists app_state (
  org_id uuid primary key references orgs(id) on delete cascade,
  data jsonb not null,
  version int not null default 1,
  updated_at timestamptz not null default now(),
  updated_by uuid);
create table if not exists app_state_history (
  id bigserial primary key,
  org_id uuid references orgs(id) on delete cascade,
  version int, data jsonb,
  saved_at timestamptz not null default now());

create or replace function is_admin() returns boolean language sql security definer stable set search_path=public as $$
  select exists(select 1 from profiles where user_id=auth.uid() and role='admin') $$;
create or replace function my_org() returns uuid language sql security definer stable set search_path=public as $$
  select org_id from profiles where user_id=auth.uid() $$;

create or replace function keep_history() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into app_state_history(org_id,version,data) values (old.org_id,old.version,old.data);
  delete from app_state_history where org_id=old.org_id and id not in
    (select id from app_state_history where org_id=old.org_id order by id desc limit 30);
  return new;
end $$;
drop trigger if exists trg_hist on app_state;
create trigger trg_hist before update on app_state for each row execute function keep_history();

alter table orgs enable row level security;
alter table profiles enable row level security;
alter table app_state enable row level security;
alter table app_state_history enable row level security;

drop policy if exists orgs_r on orgs; drop policy if exists orgs_w on orgs;
drop policy if exists prof_r on profiles; drop policy if exists prof_w on profiles;
drop policy if exists st_r on app_state; drop policy if exists st_i on app_state; drop policy if exists st_u on app_state;
drop policy if exists hi_r on app_state_history;
create policy orgs_r on orgs for select to authenticated using (is_admin() or id=my_org());
create policy orgs_w on orgs for all to authenticated using (is_admin()) with check (is_admin());
create policy prof_r on profiles for select to authenticated using (user_id=auth.uid() or is_admin());
create policy prof_w on profiles for all to authenticated using (is_admin()) with check (is_admin());
create policy st_r on app_state for select to authenticated using (org_id=my_org() or is_admin());
create policy st_i on app_state for insert to authenticated with check (is_admin() or (org_id=my_org() and exists(select 1 from orgs where id=org_id and active)));
create policy st_u on app_state for update to authenticated using (is_admin() or (org_id=my_org() and exists(select 1 from orgs where id=org_id and active))) with check (is_admin() or org_id=my_org());
create policy hi_r on app_state_history for select to authenticated using (org_id=my_org() or is_admin());

create or replace function link_user(p_email text,p_org uuid,p_role text default 'member') returns void language plpgsql security definer set search_path=public,auth as $$
declare uid uuid;
begin
  if not is_admin() then raise exception 'not allowed'; end if;
  select id into uid from auth.users where lower(email)=lower(p_email);
  if uid is null then raise exception 'user not found'; end if;
  insert into profiles(user_id,org_id,role) values(uid,p_org,p_role)
  on conflict (user_id) do update set org_id=excluded.org_id, role=excluded.role;
end $$;
create or replace function admin_users() returns table(user_id uuid,email text,org_id uuid,role text) language sql security definer stable set search_path=public,auth as $$
  select p.user_id,u.email::text,p.org_id,p.role from profiles p join auth.users u on u.id=p.user_id where is_admin() $$;
revoke all on function link_user(text,uuid,text) from public, anon;
revoke all on function admin_users() from public, anon;
grant execute on function link_user(text,uuid,text) to authenticated;
grant execute on function admin_users() to authenticated;

create or replace view org_stats with (security_invoker=on) as
  select s.org_id,o.name,o.active,s.version,s.updated_at,(s.data->>'year')::int as year,
  jsonb_array_length(s.data->'mem') as members, jsonb_array_length(s.data->'v') as vouchers
  from app_state s join orgs o on o.id=s.org_id;
grant select on org_stats to authenticated;

-- الأدمن الأول: بدّل البريد ببريد حساب الأدمن الذي أنشأته في Authentication
-- insert into profiles(user_id,role) select id,'admin' from auth.users where email='بريدك@example.com'
-- on conflict (user_id) do update set role='admin';
